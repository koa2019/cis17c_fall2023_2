/* 
 * File:    main.cpp
 * Author:  Danielle F
 * Created: 09-05-2023 @ 9PM
 * Purpose:  
 * Summation of i=1 to n and summation of i=m to n = n-m+1.
 */

//System Libraries
#include <bits/stdc++.h> 
using namespace std;  //STD Name-space where Library is compiled

//User Libraries

//Global Constants not Variables
//Math/Physics/Science/Conversions/Dimensions

//Function Prototypes

//Code Begins Execution Here with function main
int main(int argc, char** argv) {
    //Set random number seed once here
    srand(static_cast<unsigned int>(time(0)));
    
    //Declare variables here
    int start, n, m, sum, constant;
    n=m=sum=0;
    start=constant=1;
    
    //Initialize variables here
    cout<<"Summation of i=1 to n\n";
    cout<<"Enter constant ";
    cin>>constant;
    //cout<<"Enter i ";
    //cin>>start;   
    //cout<<"Enter n ";
    //cin>>n;
    constant=rand()%9+1;// [10,90]
    n=rand()%90+10;// [10,90]
    
    //Map inputs to outputs here   
    for(int i=start; i<=n;i++){
        sum+=constant;
    }
    
    //Display the results
    cout<<"C   = "<<constant<<endl
        <<"i   = "<<start<<endl
        <<"n   = "<<n<<endl
        <<"sum = "<<sum<<endl<<endl;
    
    
    cout<<"Summation of i=m to n\n";
    //cout<<"Enter m ";
    //cin>>m;
    m=rand()%(n-1)+11;
    cout<<"C   = "<<constant<<endl
        <<"m   = "<<m<<endl
        <<"n   = "<<n<<endl
        <<"sum = "<<"n-m+1"<<endl
        <<"sum = "<<sum<<"-"<<m<<"+1="<<(sum-m+1)<<endl<<endl;    
    
    return 0;
}