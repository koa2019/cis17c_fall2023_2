/* 
 * File:    main.cpp
 * Author:  Danielle F
 * Created: 08-24-2023 @ 10 PM
 * Purpose:  
 */

//System Libraries
#include <bits/stdc++.h> 
using namespace std;  //STD Name-space where Library is compiled

//User Libraries

//Global Constants not Variables
//Math/Physics/Science/Conversions/Dimensions

//Function Prototypes

//Code Begins Execution Here with function main
int main(int argc, char** argv) {
    //Set random number seed once here
    srand(static_cast<unsigned int>(time(0)));
    //rand()%90+10;//2 digit numbers
    
    //Declare variables here
        
    //Initialize variables here
    
    //Map inputs to outputs here, i.e. the process
    
    //Display the results
    cout<<"Hello World\n";
    return 0;
}

/**********  Function Definitions  **************/