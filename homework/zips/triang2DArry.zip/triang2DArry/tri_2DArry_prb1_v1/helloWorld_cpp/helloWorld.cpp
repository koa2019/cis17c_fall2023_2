/* 
 * File:    main.cpp
 * Author:  Danielle F
 * Created: -2022 @ 2:36 PM
 * Purpose:  gaddis_9e_ch
 */

//System Libraries
#include <iostream>  //Input/Output Library
#include <cstdlib> // rand()
#include <ctime>   // time()
#include <string> //string
#include <cstring> //c-strings
#include <cctype> // tolower()
using namespace std;  //STD Name-space where Library is compiled

//User Libraries

//Global Constants not Variables
//Math/Physics/Science/Conversions/Dimensions

//Function Prototypes

//Code Begins Execution Here with function main
int main(int argc, char** argv) {
    
        cout<<"Hello World";
        
    //Initialize variables here
    
    //Map inputs to outputs here, i.e. the process
    
    //Display the results

    return 0;
}

/**********  Function Definitions  **************/